// Flatten the nested storeData structure into one product array.
const products = [];

for (const category of storeData.categories) {
    for (const subcategory of category.subcategories) {
        for (const product of subcategory.products) {
            products.push(product);
        }
    }
}

const productMap = new Map(products.map(product => [product.id, product]));

// -------------------------
// Common helpers
// -------------------------

function formatPrice(value) {
    return "₹" + Number(value).toLocaleString("en-IN");
}

function stars(rating) {
    const full = Math.round(rating);
    return "★".repeat(full) + "☆".repeat(5 - full);
}

function productCard(product, extra = "") {
    return `
        <article class="product-card">
            ${extra}
            <div class="brand">${product.brand} • ${product.subcategory}</div>
            <h3>${product.name}</h3>
            <div class="price">${formatPrice(product.price)}</div>
            <div class="rating">${stars(product.rating)} ${product.rating} (${product.reviews} reviews)</div>
            ${product.stock !== undefined ? `<div class="popularity">Stock: ${product.stock}</div>` : ""}
            <div class="card-actions">
                <button onclick="viewProduct('${product.id}')">View Product</button>
                <button onclick="addToCart('${product.id}')">Add to Cart</button>
            </div>
        </article>
    `;
}

function renderCards(containerId, list, extraBuilder = () => "") {
    const container = document.getElementById(containerId);
    if (!list.length) {
        container.innerHTML = `<div class="empty">No products found.</div>`;
        return;
    }
    container.innerHTML = list.map((product, index) =>
        productCard(product, extraBuilder(product, index))
    ).join("");
}

// -------------------------
// Challenge 1: Smart Price Finder
// -------------------------

// Products are sorted once. Binary search is then used to locate the closest
// price instead of checking every product on every target-price search.
const productsByPrice = [...products].sort((a, b) => a.price - b.price);

function lowerBoundByPrice(target) {
    let left = 0;
    let right = productsByPrice.length;

    while (left < right) {
        const mid = Math.floor((left + right) / 2);

        if (productsByPrice[mid].price < target) {
            left = mid + 1;
        } else {
            right = mid;
        }
    }

    return left;
}

function findClosestProducts(target, count = 3) {
    if (!productsByPrice.length) return [];

    const index = lowerBoundByPrice(target);
    let left = index - 1;
    let right = index;
    const answer = [];

    while (answer.length < count && (left >= 0 || right < productsByPrice.length)) {
        if (left < 0) {
            answer.push(productsByPrice[right++]);
        } else if (right >= productsByPrice.length) {
            answer.push(productsByPrice[left--]);
        } else {
            const leftDiff = Math.abs(productsByPrice[left].price - target);
            const rightDiff = Math.abs(productsByPrice[right].price - target);

            if (leftDiff <= rightDiff) {
                answer.push(productsByPrice[left--]);
            } else {
                answer.push(productsByPrice[right++]);
            }
        }
    }

    return answer;
}

document.getElementById("findPriceBtn").addEventListener("click", () => {
    const target = Number(document.getElementById("targetPrice").value);

    if (!Number.isFinite(target) || target < 0) {
        document.getElementById("priceResults").innerHTML =
            `<div class="empty">Enter a valid target price.</div>`;
        return;
    }

    const result = findClosestProducts(target, 3);

    renderCards("priceResults", result, (product, index) =>
        `<div class="popularity">Distance from target: ${formatPrice(Math.abs(product.price - target))}</div>`
    );
});

document.getElementById("findRangeBtn").addEventListener("click", () => {
    const min = Number(document.getElementById("minPrice").value);
    const max = Number(document.getElementById("maxPrice").value);

    if (!Number.isFinite(min) || !Number.isFinite(max) || min < 0 || max < min) {
        document.getElementById("priceResults").innerHTML =
            `<div class="empty">Enter a valid minimum and maximum price.</div>`;
        return;
    }

    // Since productsByPrice is sorted, binary search gives the range boundaries.
    const start = lowerBoundByPrice(min);
    const end = lowerBoundByPrice(max + 1);
    const result = productsByPrice.slice(start, end);

    renderCards("priceResults", result);
});

// -------------------------
// Challenge 2: Top K Popular Products
// -------------------------

function popularity(product) {
    return product.rating * product.reviews;
}

// Small MinHeap. The smallest popularity remains at the root.
// Keeping only K items avoids sorting the whole product list.
class MinHeap {
    constructor(compare) {
        this.items = [];
        this.compare = compare;
    }

    size() {
        return this.items.length;
    }

    peek() {
        return this.items[0];
    }

    push(value) {
        this.items.push(value);
        this.bubbleUp(this.items.length - 1);
    }

    pop() {
        if (!this.items.length) return undefined;

        const root = this.items[0];
        const last = this.items.pop();

        if (this.items.length) {
            this.items[0] = last;
            this.bubbleDown(0);
        }

        return root;
    }

    bubbleUp(index) {
        while (index > 0) {
            const parent = Math.floor((index - 1) / 2);

            if (this.compare(this.items[index], this.items[parent]) >= 0) break;

            [this.items[index], this.items[parent]] =
                [this.items[parent], this.items[index]];

            index = parent;
        }
    }

    bubbleDown(index) {
        const length = this.items.length;

        while (true) {
            let smallest = index;
            const left = index * 2 + 1;
            const right = index * 2 + 2;

            if (left < length &&
                this.compare(this.items[left], this.items[smallest]) < 0) {
                smallest = left;
            }

            if (right < length &&
                this.compare(this.items[right], this.items[smallest]) < 0) {
                smallest = right;
            }

            if (smallest === index) break;

            [this.items[index], this.items[smallest]] =
                [this.items[smallest], this.items[index]];

            index = smallest;
        }
    }
}

function topKPopular(k) {
    const heap = new MinHeap((a, b) => popularity(a) - popularity(b));

    for (const product of products) {
        heap.push(product);

        if (heap.size() > k) {
            heap.pop();
        }
    }

    const result = [];

    while (heap.size()) {
        result.push(heap.pop());
    }

    return result.reverse();
}

function renderPopular() {
    const k = Number(document.getElementById("topK").value);
    const result = topKPopular(k);

    renderCards("popularResults", result, (product, index) =>
        `<span class="rank">#${index + 1}</span>
         <div class="popularity">Popularity score: ${popularity(product).toFixed(1)}</div>`
    );
}

document.getElementById("topK").addEventListener("change", renderPopular);

// -------------------------
// Challenge 3: Recently Viewed
// -------------------------

// Map gives O(1) lookup. Array stores the display order.
// Maximum history is 5 products.
const recentHistory = [];
const recentSet = new Set();
const MAX_HISTORY = 5;

function addToRecent(productId) {
    if (recentSet.has(productId)) {
        const oldIndex = recentHistory.indexOf(productId);
        recentHistory.splice(oldIndex, 1);
    } else {
        recentSet.add(productId);
    }

    recentHistory.unshift(productId);

    while (recentHistory.length > MAX_HISTORY) {
        const removedId = recentHistory.pop();
        recentSet.delete(removedId);
    }

    renderRecent();
}

function renderRecent() {
    const recentProducts = recentHistory
        .map(id => productMap.get(id))
        .filter(Boolean);

    const container = document.getElementById("recentResults");

    if (!recentProducts.length) {
        container.innerHTML = `<div class="empty">No recently viewed products.</div>`;
        return;
    }

    container.innerHTML = recentProducts.map(product => productCard(product)).join("");
}

document.getElementById("clearHistoryBtn").addEventListener("click", () => {
    recentHistory.length = 0;
    recentSet.clear();
    renderRecent();
});

// -------------------------
// Product details
// -------------------------

function viewProduct(productId) {
    const product = productMap.get(productId);
    if (!product) return;

    addToRecent(productId);

    const specs = Object.entries(product.specifications || {})
        .map(([key, value]) => `
            <div class="detail-item">
                <strong>${key}</strong><br>${value}
            </div>
        `).join("");

    document.getElementById("modalContent").innerHTML = `
        <span class="challenge">${product.category} / ${product.subcategory}</span>
        <h2>${product.name}</h2>
        <p><strong>Brand:</strong> ${product.brand}</p>
        <p class="price">${formatPrice(product.price)}</p>
        <p class="rating">${stars(product.rating)} ${product.rating} • ${product.reviews} reviews</p>
        <p><strong>Stock:</strong> ${product.stock}</p>
        <h3>Specifications</h3>
        <div class="detail-grid">${specs}</div>
        <button onclick="addToCart('${product.id}'); closeModal();">Add to Cart</button>
    `;

    document.getElementById("productModal").classList.remove("hidden");
}

function closeModal() {
    document.getElementById("productModal").classList.add("hidden");
}

document.getElementById("closeModal").addEventListener("click", closeModal);

document.getElementById("productModal").addEventListener("click", (event) => {
    if (event.target.id === "productModal") closeModal();
});

// -------------------------
// Challenge 4: Undo / Redo Cart
// -------------------------

let cart = new Map();
let undoStack = [];
let redoStack = [];
let operationHistory = [];

function cloneCart(source) {
    return new Map(
        [...source].map(([id, item]) => [id, { ...item }])
    );
}

function saveState(operationText) {
    undoStack.push({
        cart: cloneCart(cart),
        operationHistory: [...operationHistory]
    });

    // A new operation after Undo creates a new branch.
    redoStack = [];

    operationHistory.push(operationText);

    if (operationHistory.length > 20) {
        operationHistory.shift();
    }

    updateCartUI();
}

function addToCart(productId) {
    const product = productMap.get(productId);
    if (!product) return;

    saveState(`Added ${product.name}`);

    if (cart.has(productId)) {
        cart.get(productId).quantity += 1;
    } else {
        cart.set(productId, {
            productId,
            name: product.name,
            price: product.price,
            quantity: 1
        });
    }

    updateCartUI();
}

function removeFromCart(productId) {
    if (!cart.has(productId)) return;

    const item = cart.get(productId);
    saveState(`Removed ${item.name}`);
    cart.delete(productId);
    updateCartUI();
}

function changeQuantity(productId, amount) {
    if (!cart.has(productId)) return;

    const item = cart.get(productId);
    const newQuantity = item.quantity + amount;

    if (newQuantity <= 0) {
        removeFromCart(productId);
        return;
    }

    saveState(
        `${amount > 0 ? "Increased" : "Decreased"} ${item.name} quantity`
    );

    item.quantity = newQuantity;
    updateCartUI();
}

function undo() {
    if (!undoStack.length) return;

    redoStack.push({
        cart: cloneCart(cart),
        operationHistory: [...operationHistory]
    });

    const previous = undoStack.pop();
    cart = previous.cart;
    operationHistory = previous.operationHistory;

    updateCartUI();
}

function redo() {
    if (!redoStack.length) return;

    undoStack.push({
        cart: cloneCart(cart),
        operationHistory: [...operationHistory]
    });

    const next = redoStack.pop();
    cart = next.cart;
    operationHistory = next.operationHistory;

    updateCartUI();
}

document.getElementById("undoBtn").addEventListener("click", undo);
document.getElementById("redoBtn").addEventListener("click", redo);

function getCartItemCount() {
    let count = 0;
    for (const item of cart.values()) {
        count += item.quantity;
    }
    return count;
}

function getCartTotal() {
    let total = 0;
    for (const item of cart.values()) {
        total += item.price * item.quantity;
    }
    return total;
}

function cartHTML() {
    if (!cart.size) return "";

    return [...cart.values()].map(item => `
        <div class="cart-row">
            <div>
                <h3>${item.name}</h3>
                <div>${formatPrice(item.price)} each</div>
            </div>
            <div class="qty">
                <button class="secondary" onclick="changeQuantity('${item.productId}', -1)">−</button>
                <strong>${item.quantity}</strong>
                <button onclick="changeQuantity('${item.productId}', 1)">+</button>
            </div>
            <button class="remove" onclick="removeFromCart('${item.productId}')">Remove</button>
        </div>
    `).join("");
}

function updateCartUI() {
    const count = getCartItemCount();
    const total = getCartTotal();

    document.getElementById("cartCount").textContent = count;
    document.getElementById("summaryItems").textContent = count;
    document.getElementById("cartTotal").textContent = formatPrice(total);
    document.getElementById("sideCartTotal").textContent = formatPrice(total);

    document.getElementById("cartItems").innerHTML = cartHTML();
    document.getElementById("sideCartItems").innerHTML =
        cart.size ? [...cart.values()].map(item => `
            <div class="side-cart-row">
                <strong>${item.name}</strong>
                <div>${item.quantity} × ${formatPrice(item.price)}</div>
                <div class="qty">
                    <button class="secondary" onclick="changeQuantity('${item.productId}', -1)">−</button>
                    <span>${item.quantity}</span>
                    <button onclick="changeQuantity('${item.productId}', 1)">+</button>
                    <button class="remove" onclick="removeFromCart('${item.productId}')">Remove</button>
                </div>
            </div>
        `).join("") : `<div class="empty">Your cart is empty.</div>`;

    document.getElementById("cartEmpty").style.display =
        cart.size ? "none" : "block";

    document.getElementById("undoBtn").disabled = undoStack.length === 0;
    document.getElementById("redoBtn").disabled = redoStack.length === 0;

    const history = document.getElementById("operationHistory");
    history.innerHTML = operationHistory.length
        ? operationHistory.map(op => `<li>✓ ${op}</li>`).join("")
        : `<li>No operations yet.</li>`;
}

// -------------------------
// Cart side panel
// -------------------------

function openCart() {
    document.getElementById("cartPanel").classList.add("open");
    document.getElementById("overlay").classList.remove("hidden");
}

function closeCart() {
    document.getElementById("cartPanel").classList.remove("open");
    document.getElementById("overlay").classList.add("hidden");
}

document.getElementById("cartOpenBtn").addEventListener("click", openCart);
document.getElementById("cartCloseBtn").addEventListener("click", closeCart);
document.getElementById("overlay").addEventListener("click", closeCart);

// Initial UI
renderPopular();
renderRecent();
updateCartUI();
