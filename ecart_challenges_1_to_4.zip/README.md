# eCart - Challenges 1 to 4

Implemented using the original `data.js` dataset.

## Files
- `index.html` - UI
- `style.css` - responsive styling
- `script.js` - Challenges 1 to 4
- `data.js` - original repository dataset

## Challenges
1. Smart Price Finder
   - One-time price sorting
   - Binary search for target/range boundaries
2. Top K Popular Products
   - Popularity = rating × reviews
   - Min-heap keeps only K products
3. Recently Viewed Products
   - Set for fast duplicate lookup
   - Array for newest-first order
   - Maximum 5 products
4. Undo / Redo Cart
   - Two stacks: undo and redo
   - Cart snapshots make every operation reversible

## Run
Simply open `index.html` in a browser.

If the browser blocks local scripts, use VS Code Live Server or another local static server.
